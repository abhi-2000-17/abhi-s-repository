package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;

@Service
public class BookService {
	@Autowired
	private BookRepository repo;
	
	public String saveBook(Book book)
	{
		repo.save(book);
		return "book saved";
	}
	public Book getBook(int bookId)
	{
		return repo.findById(bookId).get();
	}
	public List<Book> removeBook(int bookId)
	{
		repo.deleteById(bookId);
		return repo.findAll();
	}

}
