package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Book;
import com.example.demo.service.BookService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/book")
public class BookController {
	@Autowired
	private BookService serv;
	@PostMapping("/save")
	@ApiOperation("store book api")
	public String saveBook(Book book)
	{
		return serv.saveBook(book);
	}
	@GetMapping("/searchBook/{bookId}")
	public Book getBook(@PathVariable int bookId)
	{
		return serv.getBook(bookId);
	}
	@DeleteMapping("/searchBook/{bookId}")
	public List<Book> deleteBook(@PathVariable int bookId)
	{
		return serv.removeBook(bookId);
	}

}
