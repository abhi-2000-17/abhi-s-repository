package com.example.demo;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class TokenSecurity1Application {
	@Autowired
	private UserRepository repo;
	@PostConstruct
	public void initUsers()
	{
		List<User> users=Stream.of(new User(1,"js","pwd","js@g"),new User(2,"ps","pwd1","ps@g"),new User(3,"ks","pwd","ks@g")).collect(Collectors.toList());
		repo.saveAll(users);
	}
	public static void main(String[] args) {
		SpringApplication.run(TokenSecurity1Application.class, args);
	}

}
