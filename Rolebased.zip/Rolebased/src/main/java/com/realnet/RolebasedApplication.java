package com.realnet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RolebasedApplication {

	public static void main(String[] args) {
		SpringApplication.run(RolebasedApplication.class, args);
	}

}
