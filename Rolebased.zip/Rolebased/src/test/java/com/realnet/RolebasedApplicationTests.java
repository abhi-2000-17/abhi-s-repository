package com.realnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RolebasedApplicationTests {

	@Test
	void contextLoads() {
	}

}
