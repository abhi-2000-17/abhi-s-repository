package com.example.demo;

import java.io.File;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.controller.EmployeeController;

@SpringBootApplication
public class EmployeeManagementAppApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(EmployeeManagementAppApplication.class, args);
	}

}
