package com.example.demo.service;

import java.io.IOException;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Employee;

public interface EmployeeService {
	List<Employee> getAllEmployees();
	Employee saveEmployee(Employee employee);
	Employee getEmployeeById(int id);
	void deleteEmployeeById(Integer id);
	List<Employee> findByDepartment(String department);
	List<Employee> findByPosition(String position);
	Page<Employee> getLimitedEmployees(int n);
	
	void saveImage(MultipartFile imageFile) throws Exception;
	
}
