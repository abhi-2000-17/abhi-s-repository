package com.example.demo.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository repo;

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	

	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		Optional<Employee> e=this.repo.findById(id);
		Employee employee=null;
		if(e.isPresent())
		{
			employee=e.get();
		}
		else
		{
			throw new RuntimeException("Employee not found for id:"+id);
		}
		return employee;
				
		
	}

	@Override
	public void deleteEmployeeById(Integer id) {
		// TODO Auto-generated method stub
		this.repo.deleteById(id);
		
	}
	@Override
	public Page<Employee> getLimitedEmployees(int n) {
		// TODO Auto-generated method stub
		Page<Employee> page=repo.findAll(PageRequest.of(0, n));
		return page;
	}

	@Override
	public List<Employee> findByDepartment(String department) {
		// TODO Auto-generated method stub
		List<Employee> e=repo.findByDepartment(department);
		return e;
	}

	@Override
	public List<Employee> findByPosition(String position) {
		// TODO Auto-generated method stub
		List<Employee> e=repo.findByPosition(position);
		return e;
	}

	@Override
	public Employee saveEmployee(Employee employee) {
		return this.repo.save(employee);
		
		
	}

	@Override
	public void saveImage(MultipartFile imageFile) throws Exception {
		String folder="/photos/";
		byte[] bytes=imageFile.getBytes();
		Path path=Paths.get(folder+imageFile.getOriginalFilename());
		Files.write(path, bytes);
		
	}

	


	

	

}
