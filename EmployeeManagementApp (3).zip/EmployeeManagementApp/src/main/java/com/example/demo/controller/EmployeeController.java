package com.example.demo.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.example.demo.FileUploadUtil;
import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService serv;

	/*
	 * public static String
	 * uploadDirectory=System.getProperty("user.dir")+"/src/main/webapp";
	 */
  @GetMapping("/")
   public String viewHomePage(Model model)
   {
	  model.addAttribute("ListEmployees",serv.getAllEmployees() );
	  return "index";
   }
  @GetMapping("/shownewEmployeeForm")
  public String shownewEmployeeForm(Model model)
  {
	  Employee employee=new Employee();
	  model.addAttribute("employee", employee);
	  return "new_employee";
  }
  @PostMapping("/saveEmployee")
   public RedirectView saveEmployee(@ModelAttribute("product")Employee emp,@RequestParam("image") MultipartFile file) throws IOException 
  {
	  
	 String fileName=StringUtils.cleanPath(file.getOriginalFilename());
	 emp.setPhoto(fileName);
	 Employee saveemp=serv.saveEmployee(emp);
	 String uploadDir="employee-photos/"+saveemp.getFirst_name();
	 FileUploadUtil.saveFile(uploadDir,fileName,file);
	 return new RedirectView("/",true);
  }
  @GetMapping("/showFormForUpdate/{id}")
  public String showFormForUpdate(@PathVariable(value="id") Integer id,Model model)
  {
	 Employee employee=serv.getEmployeeById(id);
	 model.addAttribute("employee",employee);
	 return "update_employee";
  }
  @GetMapping("/deleteEmployee/{id}")
  public String deleteEmployee(@PathVariable(value="id") Integer id)
  {
	  this.serv.deleteEmployeeById(id);
	  return "redirect:/";
  }
  @ResponseBody
  @GetMapping("/limitedemployees/{n}")
  public Page<Employee> pagination(@PathVariable(value="n") int n) {
		// TODO Auto-generated method stub
		Page<Employee> page=serv.getLimitedEmployees(n);
		return page;
	}
  @ResponseBody
  @GetMapping("/filterdept/{department}")
  public List<Employee> filterbydepartment(@PathVariable(value="department") String department) {
		// TODO Auto-generated method stub
		List<Employee> e=serv.findByDepartment(department);
		return e;
	}
  @ResponseBody
  @GetMapping("/filterposition/{position}")
  public List<Employee> filterbyposition(@PathVariable(value="position") String position) {
		// TODO Auto-generated method stub
		List<Employee> e=serv.findByPosition(position);
		return e;
	}
	/*
	 * @PostMapping("/uploadImage") public String
	 * uploadImage(@RequestParam("imageFile") MultipartFile imageFile) throws
	 * Exception { serv.sa return "save"; }
	 */
  
}
