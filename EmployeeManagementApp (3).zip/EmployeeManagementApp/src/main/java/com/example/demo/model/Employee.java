package com.example.demo.model;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Entity
@Table(name="employees")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	private String first_name;
	private String last_name;
	private int salary;
	private String department;
	private String position;
	private String email_address;
	private Long contact_number;
	private String photosImagePath;
	private String photo;
	
	
	
	
	
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", first_name=" + first_name + ", last_name=" + last_name + ", salary=" + salary
				+ ", department=" + department + ", position=" + position + ", email_address=" + email_address
				+ ", contact_number=" + contact_number + ", photo=" + photo + "]";
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) throws IOException {
		
		 this.photo=photo;
		
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public Long getContact_number() {
		return contact_number;
	}
	public void setContact_number(Long contact_number) {
		this.contact_number = contact_number;
	}
	public Employee(Integer id, String first_name, String last_name, int salary, String department, String position,
			String email_address, Long contact_number) {
		
		this.id = id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.salary = salary;
		this.department = department;
		this.position = position;
		this.email_address = email_address;
		this.contact_number = contact_number;
	}
	public Employee() {
		
	}
	public String getPhotosImagePath() {
	 return "/employee-photos/"+first_name+"/"+photo;
	}
	
	


}
